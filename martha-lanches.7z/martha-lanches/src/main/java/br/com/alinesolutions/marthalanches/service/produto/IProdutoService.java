package br.com.alinesolutions.marthalanches.service.produto;

import br.com.alinesolutions.marthalanches.model.Produto;
import br.com.alinesolutions.marthalanches.service.IBaseService;

public interface IProdutoService extends IBaseService<Produto, Long> {

}

package br.com.alinesolutions.marthalanches.service.cliente;

import br.com.alinesolutions.marthalanches.model.Cliente;
import br.com.alinesolutions.marthalanches.service.IBaseService;

public interface IClienteService extends IBaseService<Cliente, Long> {

}

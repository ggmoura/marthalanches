package br.com.alinesolutions.marthalanches.util;

public interface Constante {

	public interface App {
		String MENSAGEM_EMAIL_INVALIDO = "Email inválido";
		String PATTERN_EMAIL = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		String MENSAGEM_NOME_INVALIDO = "Nome Inválido";
		String MENSAGEM_APENAS_NUMEROS = "Apentas Números";
		String MENSAGEM_APENAS_NUMEROS_DECIMAIS = "Apentas Números Decimais";
		String MENSAGEM_TELEFONE_DEZ_NUMEROS = "O telefone deve conter 10 numeros";
	}
	
}
